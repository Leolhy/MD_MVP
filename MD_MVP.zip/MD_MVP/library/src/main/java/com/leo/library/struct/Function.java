package com.leo.library.struct;

/**
 * Creator: Leoying
 * Date: 2019-01-25 14:35
 */
public abstract class Function {

    public String functionName;

    public Function(String functionName) {
        this.functionName = functionName;
    }

}
