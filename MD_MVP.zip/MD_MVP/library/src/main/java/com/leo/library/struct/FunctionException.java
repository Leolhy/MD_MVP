package com.leo.library.struct;

/**
 * Creator: Leoying
 * Date: 2019-01-25 15:10
 */
public class FunctionException extends Exception {

    public FunctionException(String message) {
        super(message);
    }
}
