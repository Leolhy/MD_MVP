package com.leo.library.utils;

/**
 * Creator: Leoying
 * Date: 2018-12-06 20:59
 */
class Contacts {
    public static String BASE_URL = "http://www.wanandroid.com/tools/mockapi/7402/";
}
