package com.leo.md_mvp;

import com.leo.library.base.IMVPBaseView;

/**
 * Creator: Leoying
 * Date: 2018-11-08 11:05
 */
public interface MainView extends IMVPBaseView {
}
